package org.example.CA1.Controller;

import org.example.CA1.DAO.MovieDAO;
import org.example.CA1.DAO.UserDAO;
import org.example.CA1.Entity.Movie;
import org.example.CA1.Entity.User;
import org.example.CA1.Error.AgeLimitError;
import org.example.CA1.Error.UserAlreadyExist;
import org.example.CA1.Error.UserNotExist;
import org.example.CA1.Manager.UserManager;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
    public static String addUser(User user) throws UserAlreadyExist {
        if (UserManager.uniqueMail(user)) {
            UserManager.addUser(user);
            return "user added successfully";
        } else {
            throw new UserAlreadyExist();
        }
    }
    @PostMapping("/movies/{email}/{movieId}")
    public void addToWatchList(@RequestParam String email,@RequestParam Integer movieId) throws AgeLimitError, UserNotExist {
        User user = UserDAO.getUserBymail(email);
        Movie movie = MovieDAO.getMovieByID(movieId);
        if (UserManager.uniqueMail(user)) {
            throw new UserNotExist();
        }
        else {
            if (UserManager.checkAge(user.getBirthDate(), movie.getAgeLimit())) {
                UserManager.addToWatchList(user.getEmail(), movie.getId());
            } else {
                throw new AgeLimitError();
            }
        }
    }
    @DeleteMapping("/watchlist")
    public void removeFromWatchList(@RequestParam Integer movieId) throws AgeLimitError, UserNotExist{
        User user = UserDAO.getUserBymail(UserDAO.getEnrolledID());
        Movie movie = MovieDAO.getMovieByID(movieId);
        if (UserManager.uniqueMail(user)) {
            throw new UserNotExist();
        }
        else {
            if (UserManager.checkAge(user.getBirthDate(), movie.getAgeLimit())) {
                UserManager.removeFromWatchList(user.getEmail(), movie.getId());
            } else {
                throw new AgeLimitError();
            }
        }
    }
}
