package org.example.CA1.Controller;

import org.example.CA1.DAO.MovieDAO;
import org.example.CA1.Entity.Actor;
import org.example.CA1.Entity.Movie;
import org.example.CA1.Manager.ActorManager;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class ActorController {
    public void addActor(Actor actor){
        ActorManager.addActor(actor);
    }
    @GetMapping("/actors/{id}")
    public List<Movie> getMovieActed(@PathVariable Integer actorID){
        List<Movie> actsList = new ArrayList<Movie>();
        List<Movie> movies = MovieDAO.getMovies();
        for (Movie result : movies) {
            List<Integer> casts =  result.getCast();
            for (int i = 0; i < casts.size(); i++) {
                if(casts.get(i) == actorID) {
                    actsList.add(result);
                }
            }
        }
        return actsList;
    }
}
