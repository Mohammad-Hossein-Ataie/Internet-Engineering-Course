package org.example.CA1.Controller;

import org.example.CA1.DAO.UserDAO;
import org.example.CA1.Entity.User;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SignUpcontroller {
    @PostMapping("/signup")
    public void signup(@RequestBody User user) throws Exception {
        UserDAO.addEnrolled(user.getEmail());
        UserDAO.addUser(user);
    }
}

