package org.example.CA1.Controller;

import org.example.CA1.Entity.Actor;
import org.example.CA1.Entity.Movie;
import org.example.CA1.Error.ActorNotFound;
import org.example.CA1.Manager.MovieManager;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
@RestController
public class MovieController {

    public void isActorsValid(List<Actor> actors, Movie movie) throws ActorNotFound {
        for (int i = 0; i < actors.size(); i++) {
            if (movie.getCast().contains(actors.get(i))) {
                continue;
            } else {
                throw new ActorNotFound();
            }
        }
    }
    public static void addMovie(Movie movie) {
        MovieManager.addMovie(movie);
//        return "movie added successfully";
    }
    @GetMapping("/movies/{id}")
    public Movie getMovieById(@PathVariable Integer id) {
        return MovieManager.getMovieById(id);
    }
    @GetMapping("/movies")
    public List<Movie> getMoviesByGenre(@RequestParam String genre) {
        if(genre == null) {
            return MovieManager.getMoviesList(); //returns json string
        }
        return MovieManager.getMoviesByGenre(genre);
    }
}
