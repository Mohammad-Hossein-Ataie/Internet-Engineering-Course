export const DOMAIN = "http://backend:8080";
export let USER_LOGIN_URL = DOMAIN + "login/";
export let USER_LOGOUT_URL = DOMAIN + "logout/";
export let MOVIES_URL = DOMAIN + "movies/";
export let MOVIE_URL = DOMAIN + "movies/";
export let ACTORS_URL = DOMAIN + "actors/";
export let WATCHLIST_URL = DOMAIN + "watchlist";
export let ADD_TO_WATCHLIST = '/addwatch';
