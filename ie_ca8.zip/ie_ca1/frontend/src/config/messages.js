export const INVALID_LOGIN = "نام کاربری یا رمز عبور اشتباه است";
export const WATCHLIST_ADDED = "فیلم به لیست مشاهده اضافه شد";
export const ERR_WATCHLIST_ADDED = "خطا در اضافه کردن به لیست";
export const EMPTY_WATCHLIST = "شما قبلا فیلمی به لیست اضافه نکرده اید!";
export const LOGOUT_USER = "با موفقیت از حساب خارج شدید";

