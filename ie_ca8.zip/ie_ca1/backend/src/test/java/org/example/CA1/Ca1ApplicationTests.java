package org.example.CA1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ca1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
