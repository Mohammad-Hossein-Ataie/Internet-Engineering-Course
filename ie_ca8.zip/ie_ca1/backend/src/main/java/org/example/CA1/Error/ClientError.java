package org.example.CA1.Error;

public class ClientError extends Throwable {
    @Override
    public String getMessage() {
        return super.getMessage();
    }
}
