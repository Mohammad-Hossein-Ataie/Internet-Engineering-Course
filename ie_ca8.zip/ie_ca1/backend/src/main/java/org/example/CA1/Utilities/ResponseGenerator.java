package org.example.CA1.Utilities;

public class ResponseGenerator {

    public String printResponse(boolean bol, String comment) {
        System.out.println(comment);
        return comment;
    }
}
