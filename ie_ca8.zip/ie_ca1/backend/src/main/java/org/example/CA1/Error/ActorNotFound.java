package org.example.CA1.Error;

public class ActorNotFound extends ClientError {
    private static final String message = "actor not found";
}
