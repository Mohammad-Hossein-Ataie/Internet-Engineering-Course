package org.example.CA1.Utilities;

public class GenerateResponse {

    public String printResponse(boolean bol, String comment) {
        System.out.println(comment);
        return comment;
    }
}
