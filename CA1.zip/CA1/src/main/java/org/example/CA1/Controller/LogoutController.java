package org.example.CA1.Controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.example.CA1.DAO.UserDAO;
import org.example.CA1.Utilities.GenerateResponse;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

public class LogoutController {
    @RequestMapping("/logout")
    @ResponseBody
    public String logout() throws JsonProcessingException {
        UserDAO.setEnrolledID("");
        GenerateResponse res = new GenerateResponse();
        return res.printResponse(true, "با موفقیت خارج شدید");
    }
}
