package org.example.CA1.Controller;

import org.example.CA1.DAO.UserDAO;
import org.example.CA1.Entity.Logedin;
import org.example.CA1.Manager.UserManager;
import org.springframework.web.bind.annotation.*;
import com.fasterxml.jackson.databind.JsonNode;

import java.io.IOException;


@RestController
public class LoginController {

    @RequestMapping("/login")
    @ResponseBody
    public String login(@RequestBody Logedin user) throws Exception {
            if (user.getUsername() != null || user.getPassword()!=null)
                throw new Exception("Missing Parameter");

            if(UserManager.checkUser(user.getUsername())) {

                if(UserManager.checkPassword((user.getPassword()))){
                    UserDAO.addEnrolled(user.getUsername());
                }
                else{
                    throw  new Exception("Incorrect password.");
                }
        }
            else{
                throw new Exception("Not Registered!");
            }
        return null;
    }
}
